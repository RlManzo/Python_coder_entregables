from setuptools import setup

setup(
    name= "segunda_pre-entrega_Manzo",
    version= "1.0",
    description= "Segundo entregable de curso de Python de Coderhouse",
    author= "Ricardo Manzo",
    author_email="ricardojuliomanzo@gmail.com",

    packages= ["entrega_2"]
)